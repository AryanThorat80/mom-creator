from datetime import datetime, timezone
from typing import Any

import httpx

ZOOM_API_BASE_URL = "https://api.zoom.us/v2"


class ZoomAPIError(RuntimeError):
    pass


async def create_zoom_meeting(access_token: str, meeting_date: datetime | None, title: str) -> dict[str, Any]:
    start_time = meeting_date
    if start_time is not None and start_time.tzinfo is None:
        start_time = start_time.replace(tzinfo=timezone.utc)

    payload: dict[str, Any] = {
        "topic": title,
        "type": 2,
        "duration": 60,
        "settings": {
            "join_before_host": True,
            "waiting_room": False,
        },
    }

    if start_time:
        payload["start_time"] = start_time.isoformat()

    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            f"{ZOOM_API_BASE_URL}/users/me/meetings",
            headers={
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
            },
            json=payload,
        )

    if response.status_code >= 400:
        try:
            data = response.json()
        except ValueError:
            data = {}
        message = data.get("message") or data.get("reason") or response.text
        raise ZoomAPIError(f"Zoom API request failed ({response.status_code}): {message}")

    return response.json()
