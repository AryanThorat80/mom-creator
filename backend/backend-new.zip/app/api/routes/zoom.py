from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from supabase import Client

from app.core.config import get_settings
from app.core.security import get_access_token, get_supabase
from app.services.supabase import create_admin_supabase_client
from app.services.zoom import ZoomAPIError, create_zoom_meeting
from app.services.zoom_oauth import (
    build_zoom_authorization_url,
    exchange_zoom_authorization_code,
    refresh_access_token,
    save_zoom_connection,
    verify_zoom_oauth_state,
)

settings = get_settings()

router = APIRouter(
    prefix="/api/v1/integrations/zoom",
    tags=["Zoom"],
)


def get_authenticated_user(supabase: Client, access_token: str):
    try:
        response = supabase.auth.get_user(access_token)
    except Exception as exc:
        raise HTTPException(status_code=401, detail=f"Invalid authentication token: {exc}")

    if response.user is None:
        raise HTTPException(status_code=401, detail="Invalid authentication token")
    return response.user


@router.get("/connect")
async def connect_zoom(
    supabase: Client = Depends(get_supabase),
    access_token: str = Depends(get_access_token),
):
    user = get_authenticated_user(supabase, access_token)
    try:
        return {"authorization_url": build_zoom_authorization_url(user.id)}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/callback")
async def zoom_callback(
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
):
    base = settings.frontend_url.rstrip("/")

    if error:
        return RedirectResponse(
            url=f"{base}/zoom-integration?status=denied&error={error}",
            status_code=302,
        )

    if not code or not state:
        return RedirectResponse(
            url=f"{base}/zoom-integration?status=failed&error=missing_oauth_parameters",
            status_code=302,
        )

    try:
        state_data = verify_zoom_oauth_state(state)
        user_id = state_data["user_id"]
        token_data = await exchange_zoom_authorization_code(code)
        admin = create_admin_supabase_client()
        save_zoom_connection(admin, user_id, token_data)
    except Exception as exc:
        return RedirectResponse(
            url=f"{base}/zoom-integration?status=failed&error=oauth_failed",
            status_code=302,
        )

    return RedirectResponse(
        url=f"{base}/zoom-integration?status=connected",
        status_code=302,
    )


@router.post("/meetings/{meeting_id}/zoom")
async def create_zoom_for_meeting(
    meeting_id: str,
    supabase: Client = Depends(get_supabase),
    access_token: str = Depends(get_access_token),
) -> dict[str, Any]:
    user = get_authenticated_user(supabase, access_token)

    meeting_response = (
        supabase.table("meetings")
        .select("id,created_by,mode,title,meeting_date")
        .eq("id", meeting_id)
        .execute()
    )

    if not meeting_response.data:
        raise HTTPException(status_code=404, detail="Meeting not found")

    meeting = meeting_response.data[0]

    if meeting.get("created_by") != user.id:
        raise HTTPException(status_code=403, detail="Only the meeting creator can create its Zoom meeting")

    if meeting.get("mode") != "zoom":
        raise HTTPException(status_code=400, detail="Meeting mode must be zoom")

    admin = create_admin_supabase_client()

    existing = (
        admin.table("online_meeting_integrations")
        .select("*")
        .eq("meeting_id", meeting_id)
        .eq("provider", "zoom")
        .execute()
    )

    if existing.data:
        source = existing.data[0]
        return {
            "provider": "zoom",
            "meeting_id": meeting_id,
            "meeting_uri": source.get("meeting_uri"),
            "meeting_code": source.get("meeting_code"),
            "external_space_name": source.get("external_space_name"),
            "already_exists": True,
        }

    try:
        zoom_access_token = await refresh_access_token(admin, user.id)
        zoom_meeting = await create_zoom_meeting(
            zoom_access_token,
            meeting.get("meeting_date"),
            meeting.get("title") or "MOM Creator Meeting",
        )
    except LookupError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ZoomAPIError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to create Zoom meeting: {exc}") from exc

    zoom_id = str(zoom_meeting.get("id")) if zoom_meeting.get("id") is not None else None
    join_url = zoom_meeting.get("join_url")

    if not zoom_id or not join_url:
        raise HTTPException(status_code=502, detail="Zoom did not return a usable meeting")

    insert = (
        admin.table("online_meeting_integrations")
        .insert({
            "meeting_id": meeting_id,
            "provider": "zoom",
            "external_space_name": zoom_id,
            "meeting_uri": join_url,
            "meeting_code": zoom_id,
        })
        .execute()
    )

    if not insert.data:
        raise HTTPException(status_code=500, detail="Zoom meeting was created but integration record could not be stored")

    return {
        "provider": "zoom",
        "meeting_id": meeting_id,
        "meeting_uri": join_url,
        "meeting_code": zoom_id,
        "external_space_name": zoom_id,
        "start_url": zoom_meeting.get("start_url"),
        "already_exists": False,
    }


@router.get("/meetings/{meeting_id}/zoom")
async def get_zoom_for_meeting(
    meeting_id: str,
    supabase: Client = Depends(get_supabase),
    access_token: str = Depends(get_access_token),
):
    user = get_authenticated_user(supabase, access_token)

    meeting_response = (
        supabase.table("meetings")
        .select("id,created_by")
        .eq("id", meeting_id)
        .execute()
    )

    if not meeting_response.data:
        raise HTTPException(status_code=404, detail="Meeting not found")
    if meeting_response.data[0].get("created_by") != user.id:
        raise HTTPException(status_code=403, detail="Forbidden")

    admin = create_admin_supabase_client()
    response = (
        admin.table("online_meeting_integrations")
        .select("*")
        .eq("meeting_id", meeting_id)
        .eq("provider", "zoom")
        .execute()
    )

    if not response.data:
        raise HTTPException(status_code=404, detail="Zoom meeting has not been created")

    return response.data[0]
